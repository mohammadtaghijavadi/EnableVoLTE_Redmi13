EnableVoLTE_Redmi13 - README
------------------------

این ماژول برای فعال‌سازی VoLTE/IMS و نمایش آیکون VoLTE در نوار وضعیت بر روی Redmi 13 طراحی شده است.

محتویات بسته:
- module.prop
- service.sh  (اجرا در بوت توسط KernelSU)
- system.prop (propهای پیشنهادی، اگر KernelSU از آن پشتیبانی کند)
- README.md

نحوه نصب:
1) اطمینان حاصل کن گوشی روت دارد و KernelSU نصب است.
2) فایل ZIP را از طریق KernelSU نصب کن (مثل ماژول Magisk).
3) بعد از نصب و بوت، وضعیت را بررسی کن:
   - اجرا شدن لاگ: /data/local/tmp/enable_volte_boot.log
   - بررسی props: adb shell getprop persist.dbg.volte_avail_ovr
   - در تنظیمات شبکه دنبال Enhanced 4G / VoLTE باش
   - در صورت فعال نبودن آیکون IMS، یک بار تنظیمات -> شبکه را باز و گزینه را فعال کن.

هشدارها و نکات:
- اپراتور باید VoLTE را پشتیبانی کند؛ این ماژول صرفاً گزینه‌ها و propها را فعال می‌کند، اما ثبت IMS (IMS registration) به شبکه و اپراتور وابسته است.
- برای نمایش آیکون VoLTE لازم است IMS به درستی register شود؛ اگر ثبت انجام نشد ممکن است نیاز به تعویض eSIM/SIM یا تنظیمات اپراتور باشد.
- اگر بعد از نصب مشکلی مشاهده شد، فایل لاگ در /data/local/tmp/enable_volte_boot.log را ارسال کن تا بررسی کنم.
