#!/system/bin/sh
# service.sh - executed by KernelSU at boot (runs as root)
LOG=/data/local/tmp/enable_volte_boot.log
echo "$(date): EnableVoLTE service.sh start" >> $LOG

# Try to use resetprop (Magisk/toolkits) if available, else fallback to setprop (may not survive reboot)
if command -v resetprop >/dev/null 2>&1; then
  RP="resetprop -n"
else
  RP="setprop"
fi

# Apply props (best-effort)
$RP persist.dbg.volte_avail_ovr 1
$RP persist.dbg.vt_avail_ovr 1
$RP persist.dbg.wfc_avail_ovr 1
$RP persist.dbg.ims_avail_ovr 1
$RP persist.vendor.mtk.volte.enable 1
$RP persist.vendor.mtk.ims_support 1
$RP persist.vendor.radio.volte_enabled 1
$RP persist.vendor.radio.ims_switch 1
$RP persist.vendor.mtk.volte_support 1
$RP persist.vendor.mtk.wfc_support 1
$RP persist.radio.voice_on_lte 1
$RP persist.radio.calls.on.ims 1

# Enable Enhanced 4G in settings (framework)
settings put global enhanced_4g_lte_mode_enabled 1 2>> $LOG || true
settings put global volte_vt_enabled 1 2>> $LOG || true

echo "$(date): properties applied, restarting related services" >> $LOG

# Try to restart telephony / ims services to pick up changes
if command -v cmd >/dev/null 2>&1; then
  cmd activity broadcast -a android.intent.action.ACTION_BOOT_COMPLETED 2>> $LOG || true
fi

# Some devices pick up after killing systemui/phone process — avoid force-killing to reduce risk.
# Instead, politely request to restart telephony and ims if possible
if dumpsys telephony 2>/dev/null; then
  echo "$(date): dumpsys telephony exists" >> $LOG
fi

echo "$(date): EnableVoLTE service.sh end" >> $LOG
exit 0
